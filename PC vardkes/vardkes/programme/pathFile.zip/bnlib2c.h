#ifndef BNLI2BC_H
#define BNLI2BC_H

#pragma comment(lib, "bnlib2c.lib")

typedef struct _PACKDATE {
  DWORD date;
  DWORD time;
} PACKDATE, *LPPACKDATE;

#define MIN_DATE     (-657434L) /* 01/01/100  */
#define MAX_DATE     2958465L   /* 31/12/9999 */

#define PackDate(j,m,a) ((((DWORD)(a)) << 16) | ((m) << 8) | (j))

extern "C" {
char* __stdcall bntrimR(char* psz);
char* __stdcall bntrimL(char* psz);
int __stdcall bntrim(char* psz);
char* __stdcall bnReverseStr(char* psz);
char* __stdcall bnMake2FileName(char* pszdst, char* pszsrc);

char* __stdcall bnultoa(DWORD dwNbr, char* pszdst);
char* __stdcall bnitoa(DWORD dwNbr, char* pszdst);
char* __stdcall bnultoapadding(DWORD dwNbr, char* pszdst, DWORD dwlenpadd);
char* __stdcall bnultohexa(DWORD dwNbr, char* pszdst);
char* __stdcall bndw2hex(DWORD dwNbr, char* pszdst); // sort en "0000FF00"
DWORD __stdcall bnahextodw(char* psz);
int __stdcall bnatoi(char* psz);
DWORD __stdcall bnatoui(char* psz);

DWORD __stdcall bnPgdc(DWORD dwNbr1, DWORD dwNbr2); // pgdc ou 0
DWORD __stdcall bnSqrt32(DWORD dwNbr, DWORD *dwRest); // *dwRest option sinon met 0

int __stdcall bnDirExists(char* psz);   // ret 0 ou 16
int __stdcall bnFileExists(char* psz);  // ret 0 ou 1
char* __stdcall bnFileExtension(char* psz);
  // ret 0 ou ptr sur 1er char de extension
  // Myfile.asm retourne ptr sur a, Myfileasm retourne 0
DWORD __stdcall bnSelectDir(HWND hOwner, char* pszTitle, char* pszDirSel);
DWORD __stdcall bnSelectFile(HWND hOwner, char* pszFile, char* pszTitle,
                             char* pszFltr, DWORD *pFltrIdx, DWORD noChngdir);
    // return !=0 si fichier choisi, sinon pszFile[0] = 0
    // *pFltrIdx de base 1, option peut mettre 0 au lieu du pointeur
    // noChngdir passer !=0 pour de pas changer de CurrentDirectory
DWORD __stdcall bnGetAppPath(char* pszDst);
void __stdcall bnSetAppCurrPath(VOID);
int  __stdcall bnIsNotFixedDrive(char *psz); // full path possible
int  __stdcall bnIsNotCdromDrive(char *psz); // full path possible
unsigned _int64 __stdcall bnGetDiskFreeSpace(char* psz); // full path possible
void __stdcall bnDispSysMsgError(HWND hOwner, char* pszTitle);

int __stdcall bnIsWinTypeNT();  // ret 0 ou !=0(2)
DWORD __stdcall bnWinVersion();
// probleme  => 0
// w95.1     => 0x100
// w95.2     => 0x101
// w98.1     => 0x200
// w98.2     => 0x201
// wME       => 0x300
// NT3.51    => 0
// NT4.0     => 0x4sp
// 2000      => 0x5sp
// XP        => 0x6sp
// Net serv  => 0x7sp
DWORD __stdcall bnGetCpuSpeed();

DWORD __stdcall bnLongToDatePack(long ldat);
long __stdcall bnSttmToLong(SYSTEMTIME *sttm);
long __stdcall bnDatePackToLong(DWORD datp);

DWORD __stdcall bnCurrPackDate();
void __stdcall bnCurrFullPackDate(LPPACKDATE pdt);

DWORD __stdcall bnGetEasterPack(DWORD annee); // >= 1582 && <= 9999 sinon ret 0

void __stdcall bnDatePackToDateFr(DWORD datp, char *psz);
void __stdcall bnTimePackToTimeFr(DWORD timp, char *psz);
char* __stdcall bnSttmToFr(SYSTEMTIME *sttm, char* pszdst); // ptr 0 final pszDst
char* __stdcall bnSttmToFullFr(SYSTEMTIME *sttm, char* pszdst); // ptr 0 final pszDst
void __stdcall bnCurrFullFrDate(char* pszdst);

}

#endif
